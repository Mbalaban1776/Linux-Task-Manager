#!/bin/bash
git archive --format=tar.gz --prefix=linux-task-manager-0.2.8/ -o linux-task-manager-0.2.8.tar.gz HEAD 