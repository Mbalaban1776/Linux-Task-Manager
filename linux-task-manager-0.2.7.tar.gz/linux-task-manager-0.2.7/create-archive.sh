#!/bin/bash
git archive --format=tar.gz --prefix=linux-task-manager-0.2.7/ -o linux-task-manager-0.2.7.tar.gz HEAD 