#!/bin/bash
git archive --format=tar.gz --prefix=linux-task-manager-0.2.5/ -o linux-task-manager-0.2.5.tar.gz HEAD 